# Graph Memory Documentation

## Overview

Graph Memory is a unified memory mosaic for Agent Zero that creates a blockchain-like graph of memory nodes across all agents, enabling spatial awareness of work progress, file connections, and project state.

---

## Quick Start

### Installation

1. **Extract the ZIP file** to your Agent Zero skills folder:
   ```bash
   unzip graph-memory-skill.zip -d /a0/usr/skills/
   ```

2. **Set Graph Memory Location** (optional):
   ```bash
   export A0_GRAPH_MEMORY_ROOT="/your/custom/path"
   ```

3. **First Use**:
   ```
   You: state where MYPROJECT
   
   Agent: 📍 Graph Memory folder not found.
   Please provide a path for Graph Memory storage.
   Note: Choose a local drive repository volume-mapped to your Docker container.
   
   ✅ Graph Memory initialized at: [your path]
   📍 No checkpoints found for project 'MYPROJECT'
   ```

---

## Commands

| Command | Description |
|---------|-------------|
| `state where <project>` | Show current position in project |
| `state checkpoint <project>` | Create memory node from current session |
| `state timeline <project>` | Show chronological progression |
| `state files <project>` | List all files touched |
| `state map <project>` | Show full connection graph |
| `state cross <proj_a> <proj_b>` | Find connections between projects |

---

## Use Cases

### 1. Session Continuity

**Problem:** "I come back to a project after a week and forget where I was."

**Solution:**
```
You: state where MYPROJECT

📍 WHERE AM I?
Project: MYPROJECT
Latest Node: MEM_MYPROJECT_20260421_143052
Summary: Last work session...
Status: 🟢 Active
Next Action: Continue implementation
```

### 2. Multi-Project Management

**Problem:** "I'm working on multiple projects and losing track of progress."

**Solution:**
```
You: state timeline PROJECT_A
You: state timeline PROJECT_B
You: state timeline PROJECT_C
```

### 3. Cross-Project Dependencies

**Problem:** "I need to know which files are shared between projects."

**Solution:**
```
You: state cross PROJECT_A PROJECT_B
```

### 4. Team Coordination

**Problem:** "Multiple agents working on same codebase - need unified memory."

**Solution:** All agents share the same `connection_graph.json`

---

## A2A Integration

Graph Memory supports cross-instance queries via A2A protocol:

```json
{
  "tool_name": "a2a_chat",
  "tool_args": {
    "agent_url": "http://other-instance:8000/a2a",
    "message": "state where MYPROJECT",
    "reset": false
  }
}
```

**Compatible with:**
- Agent Zero (built-in)
- OpenClaw (if /a2a endpoint implemented)
- LangGraph, CrewAI (via FastA2A library)

---

## File Structure

```
<Graph Memory>/
├── connection_graph.json    ← THE MOSAIC (shared by all agents)
├── artifact_index.json      ← File → Memory links
├── time_index.json          ← Chronological index
├── GraphMemory_Documentation.md  ← This file
└── nodes/                   ← Individual memory nodes
    └── MEM_<PROJECT>_<TIMESTAMP>.json
```

---

## Blockchain Analogy

| Blockchain Concept | Graph Memory Equivalent |
|-------------------|------------------------|
| **Block** | Memory Node (each work session) |
| **Hash/ID** | `MEM_<PROJECT>_<TIMESTAMP>` |
| **Chain** | Connection Graph |
| **Consensus** | All agents see same graph |
| **Immutability** | Nodes are append-only |
| **Timestamps** | Every node has time marker |

---

## License

MIT
