---
name: "graph-memory"
description: "Unified memory mosaic for Agent Zero. Creates blockchain-like memory nodes across all agents for spatial awareness of work progress, file connections, and project state. Use for session continuity, multi-project management, cross-project dependencies, and team coordination."
version: "1.0.0"
author: "A0 Community"
tags: ["memory", "graph", "session", "continuity", "projects", "a2a", "checkpoint", "waypoint", "spatial"]
---

# Graph Memory Skill

## Purpose

Unified memory mosaic for Agent Zero. Creates a blockchain-like graph of memory nodes across all agents, enabling spatial awareness of work progress, file connections, and project state.

**This skill provides:"
- **Spatial Memory**: "Where am I?" in your project workflow
- **Artifact Tracking**: Files, scripts, and chats linked to memory nodes
- **Connection Discovery**: Automatic relationship detection between work sessions
- **Cross-Agent Sharing**: All agents share the same unified graph
- **A2A Integration**: Remote COO agents can query Graph Memory status

---

## Quick Start

### First Time Setup

When you first use this skill, it will check for an existing Graph Memory folder. If not found, you'll be prompted to provide a path.

```
You: state where MYPROJECT

Agent: 📍 Graph Memory folder not found.

Please provide a path for Graph Memory storage.
Note: Choose a local drive repository volume-mapped to your Docker container.

Recommended paths:
- Docker: /a0/CTO/Graph Memory/ (maps to Windows)
- Default: /a0/usr/Graph Memory/

Enter path: [your path]

✅ Graph Memory initialized at: [your path]
📍 No checkpoints found for project 'MYPROJECT'
```

### Daily Usage

```
# Start of session
You: state where MYPROJECT

📍 WHERE AM I?
Project: MYPROJECT
Latest Node: MEM_MYPROJECT_20260421_143052
Summary: Last work session...
Status: 🟢 Active
Next Action: Continue implementation

# End of session
You: state checkpoint MYPROJECT

✅ Checkpoint saved: MEM_MYPROJECT_20260421_160000
- Artifacts tracked: 3
- Connections found: 2
```

---

## Ubiquitous Design

This skill works on **any Agent Zero instance**. It auto-detects its location:

1. Environment variable: `A0_GRAPH_MEMORY_ROOT`
2. Project root: `<project_root>/Graph Memory/`
3. Workdir: `<workdir>/Graph Memory/`
4. A0 root: `/a0/usr/Graph Memory/`
## Commands

| Command | Description |
|---------|-------------|
| `state setup <path>` | **First-time setup** - Initialize Graph Memory at specified path |
| `state where <project>` | Show current position in project |
| `state checkpoint <project>` | Create memory node from current session |
| `state timeline <project>` | Show chronological progression |
| `state files <project>` | List all files touched |
| `state map <project>` | Show full connection graph |
| `state cross <proj_a> <proj_b>` | Find connections between projects |

---

## First-Time Setup

When you first use this skill on a new A0 instance, run:

```
You: state setup /path/to/Graph Memory

Agent: ✅ Graph Memory initialized at: /path/to/Graph Memory
       Created: connection_graph.json, artifact_index.json, time_index.json
       Created: nodes/ directory
```

**Recommended paths:**
- Docker: `/a0/CTO/Graph Memory/` (maps to Windows)
- Default: `/a0/usr/Graph Memory/`
- Custom: Any volume-mapped path accessible from your container

---

## Installation

### Method 1: Copy to Skills Folder

```bash
cp -r graph-memory/ /a0/usr/skills/
```

### Method 2: Extract from ZIP

```bash
unzip graph-memory-skill.zip -d /a0/usr/skills/
```

### Method 3: Clone from Repository

```bash
git clone <repo>/graph-memory /a0/usr/skills/graph-memory
```

---

## File Structure Created

```
<Graph Memory>/
├── connection_graph.json    ← THE MOSAIC (shared by all agents)
├── artifact_index.json      ← File → Memory links
├── time_index.json          ← Chronological index
├── GraphMemory_Documentation.md  ← Full documentation
└── nodes/                   ← Individual memory nodes
    └── MEM_<PROJECT>_<TIMESTAMP>.json
```

---

## Use Cases

### 1. Session Continuity

```markdown
Problem: "I come back to a project after a week and forget where I was."

Solution:
You: state where MYPROJECT
Agent: Shows exact position, recent work, next action
```

### 2. Multi-Project Management

```markdown
Problem: "I'm working on 3 projects and losing track of progress on each."

Solution:
You: state timeline PROJECT_A
You: state timeline PROJECT_B
You: state timeline PROJECT_C
```

### 3. Cross-Project Dependencies

```markdown
Problem: "I need to know which files are shared between projects."

Solution:
You: state cross PROJECT_A PROJECT_B
Agent: Shows shared files and connections
```

### 4. Team Coordination

```markdown
Problem: "Multiple agents working on same codebase - need unified memory."

Solution: All agents share same connection_graph.json
- Agent 0 creates checkpoint
- Developer subordinate sees it
- Researcher subordinate sees it
```

### 5. COO Dashboard (A2A)

```markdown
Problem: "Need a COO agent to monitor multiple A0 instances."

Solution: COO agent queries via A2A:
You (COO): a2a_chat("http://your-agent-instance:8000/a2a", "state status all")
```

---

## A2A Cross-Integration

### How A2A Works with Graph Memory

Graph Memory uses a **hybrid architecture**:

| Layer | Method | Use Case |
|-------|--------|----------|
| Same-instance agents | File-based sharing | All agents in same A0 |
| Cross-instance COO | A2A protocol | Remote monitoring, dashboard |

### FastA2A: Open Protocol

**Any FastA2A-compatible agent can query Graph Memory:**

```json
{
  "tool_name": "a2a_chat",
    "agent_url": "http://your-agent-instance:8000/a2a",
    "reset": false
  }
}
```

**Compatible agents:**
- Agent Zero (built-in)
- OpenClaw (if /a2a endpoint implemented)
- LangGraph (via FastA2A library)
- CrewAI (via FastA2A library)
- Custom agents (implement the protocol)

### COO Dashboard Example

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                         COO AGENT DASHBOARD                                       │
├─────────────────────────────────────────────────────────────────────────────────┤
│                                                                                 │
│   🏢 INSTANCE: Agent-1 (A0)                                                    │
│   ├── PROJECT_A: 🟢 Active - Feature development                                │
│   ├── PROJECT_B: 🟡 Paused - Waiting for dependencies                            │
│   └── PROJECT_C: 🔴 Blocked - Dependencies needed                                    │
│                                                                                 │
│   🏢 INSTANCE: Agent-2 (A0)                                                   │
│   ├── Content Engine: 🟢 Active - 60% complete                                  │
│                                                                                 │
│   📊 CROSS-INSTANCE ALERTS                                                     │
│   └── Project B blocked on Project A component                                   │
│                                                                                 │
└─────────────────────────────────────────────────────────────────────────────────┘
```

---

## Blockchain Analogy

Graph Memory works like a blockchain for work context:

| Blockchain Concept | Graph Memory Equivalent |
|-------------------|------------------------|
| **Block** | Memory Node (each work session) |
| **Hash/ID** | `MEM_<PROJECT>_<TIMESTAMP>` |
| **Chain** | Connection Graph |
| **Consensus** | All agents see same graph |
| **Immutability** | Nodes are append-only |
| **Timestamps** | Every node has time marker |

---

## Integration with A0 Memory

Graph Memory integrates with Agent Zero's FAISS memory:

```python
# When checkpoint is created:
# 1. Saves to connection_graph.json (shared graph)
# 2. Can save to A0 FAISS memory (for semantic search)
# 3. Creates individual node JSON file
```

---

## Files Included

| File | Description |
|------|-------------|
| `SKILL.md` | This file - skill definition and instructions |
| `graph_memory.py` | Core implementation (511 lines) |
| `README.md` | Quick start guide |
| `templates/connection_graph.json` | Fresh template for new installations |
| `templates/artifact_index.json` | Fresh template for new installations |
| `templates/time_index.json` | Fresh template for new installations |

---

## See Also

- `memory_save` - A0's FAISS memory system
- `memory_load` - Retrieve memories by query
- `a2a_chat` - Cross-instance communication
- `skills_tool` - Load other skills

---

## License

MIT
